# Design Principles Discussion

In this discussion, go to a website and navigate around as a typical user. 
Discuss with your partner what you like, dislike and what you would change. 
Make notes of the design features or flaws that you and your partner notice.

## Example Websites

Feel free to go to a website you already enjoy, OR take a look at:

- Instagram: https://instagram.com/
- CraigsList: https://craigslist.org/
- GitHub: https://github.com/
- Reddit: https://www.reddit.com/
- PaulGraham: http://paulgraham.com/
- Supreme: https://www.supremenewyork.com/
- GitHub: https://github.com/
- Reddit: https://www.reddit.com/
- PaulGraham: http://paulgraham.com/
- Supreme: https://www.supremenewyork.com/