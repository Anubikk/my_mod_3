const mrPotatoHeadQuotes = {
    "hello": "Hi, I'm Mr. Potato Head!",
    "bye": "Bye, it's been nice talking to you!"
}